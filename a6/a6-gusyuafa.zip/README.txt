# Command Instruction

The command instruction to execute part3.py is like:

'python3 part3.py ./crude ./grain'

The last two arguments are the path of the two classes documents directories.


#CSV file

The output of the file is 'result.csv'. The header of the chart is file name, class name and the list of all frame IDs. The rest rows are the the counts of each frame ID in each document according to the related frame ID of the header.


For more detail code structure, please check the comments inside the functions in the code.

